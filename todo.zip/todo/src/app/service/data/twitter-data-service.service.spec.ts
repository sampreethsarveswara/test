import { TestBed } from '@angular/core/testing';

import { TwitterDataServiceService } from './twitter-data-service.service';

describe('TwitterDataServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TwitterDataServiceService = TestBed.get(TwitterDataServiceService);
    expect(service).toBeTruthy();
  });
});
