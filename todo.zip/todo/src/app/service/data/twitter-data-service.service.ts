import { API_URL } from "./../../app.constants";
import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Todo } from "../../list-todos/list-todos.component";
import { Tweet } from "src/app/list-tweets/list-tweets.component";

@Injectable({
  providedIn: "root",
})
export class TwitterDataServiceService {
  constructor(private http: HttpClient) {}

  retrieveAllTweets(username) {
    return this.http.get<Tweet[]>(`${API_URL}/api/tweets/${username}`);
  }

  deleteTweet(username, id) {
    return this.http.delete(`${API_URL}/users/${username}/todos/${id}`);
  }

  retrieveTodo(username, id) {
    return this.http.get<Todo>(`${API_URL}/users/${username}/todos/${id}`);
  }

  updateTweet(username, id, todo) {
    return this.http.put(`${API_URL}/users/${username}/todos/${id}`, todo);
  }

  createTweet(username, todo) {
    return this.http.post(`${API_URL}/users/${username}/todos`, todo);
  }
}
