export const API_URL = "http://localhost:7071";
export const TODO_JPA_API_URL = "http://localhost:7071";
