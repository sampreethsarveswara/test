import { TwitterDataServiceService } from "./../service/data/twitter-data-service.service";
import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

export class Tweet {
  constructor(
    public id: string,
    public tweetMessage: string,
    public tweetDate: Date
  ) {}
}

@Component({
  selector: "app-list-tweets",
  templateUrl: "./list-tweets.component.html",
  styleUrls: ["./list-tweets.component.css"],
})
export class ListTweetsComponent implements OnInit {
  tweets: Tweet[];

  message: string;

  constructor(
    private twitterService: TwitterDataServiceService,
    private router: Router
  ) {}

  ngOnInit() {
    this.refreshTodos();
  }

  refreshTodos() {
    this.twitterService.retrieveAllTweets("sampreeth").subscribe((response) => {
      console.log(response);
      this.tweets = response;
    });
  }
}
